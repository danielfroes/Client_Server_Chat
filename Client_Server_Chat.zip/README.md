# Client_Server_Chat


Link Git:
https://github.com/danielfroes/Client_Server_Chat

Trabalho de redes - 1a entrega

Daniel Froés - 10255956
Luana Balador Belisário - 10692245
Pedro Henrique Nieuwenhoff - 10377729

# COMO UTILIZAR #

1) Compilar o programa do "server":

make server

2) Caso o servidor já esteva ativo, compilar
o programa do "client" com outro terminal para cada cliente:

make client

3) Seguir as instruções da interface para utilizar o chat :)
